#!/bin/bash
if [[ ! -d ~/Desktop/result ]]
then
mkdir ~/Desktop/result
fi
ls -l > ~/tmp
tail -n +2 ~/tmp > ~/tmp.tmp && mv ~/tmp.tmp ~/tmp
cut -d: -f2 ~/tmp | cut -d " " -f2 > ~/tmp1

sed -r 's/_.+//' ~/tmp1 | cat > ~/tmp

while read LINE
do
if [[ ! -d ~/Desktop/result/$LINE ]]
then
mkdir ~/Desktop/result/$LINE
fi
cp $LINE* ~/Desktop/result/$LINE/
done < ~/tmp
rm ~/tmp
rm ~/tmp1
rm -r ~/Desktop/result/task3.sh
echo "created result directory in your Desktop"
